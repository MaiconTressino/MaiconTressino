# Investida Implacável — pacote para Godot 4

## Conteúdo
- `assets/cartas/`: 22 PNGs individuais das versões escolhidas, sem redimensionamento ou distorção.
- `assets/molduras/`: 7 molduras isoladas disponíveis: Comum, Incomum, Rara, Épica, Lendária, Mítica e Celestial da Arqueira.
- `data/set_ataque.json`: nomes, classes exclusivas, bônus, parâmetros, patamares 2/4/6, mecânicas e origem externa por ato/fase.
- `data/molduras.json`: inventário e pendências de molduras.
- `godot/`: cena de catálogo e validador de importação.
- `fontes/pranchas_aprovadas/`: originais completos dos quais foram extraídas as cartas.
- `fontes/variacoes_e_estudos/`: todas as 48 pranchas locais de geração, inclusive versões descartadas e estudos; não representam aprovação.
- `fontes/molduras_alternativas/`: alternativas históricas fornecidas, separadas das molduras de uso.
- `fontes/criaturas/`: referências estáticas fornecidas, sem animações; referências não são novas cartas.
- `fontes/arqueira_v5_zoom_out.svg`: montagem editável da carta final da Arqueira, com imagens incorporadas.
- `docs/catalogo_producao.csv`: lista para produção com ato/fase fora da carta.

## Abrir a demonstração
Abra este `project.godot` como projeto independente no Godot 4. A cena inicial mostra as 22 cartas. Não substitua o `project.godot` do seu jogo.

Para integrar ao jogo existente, copie `assets/` e `data/` preservando a estrutura, ou adapte os caminhos `res://` do JSON se usar outra pasta. A cena é um exemplo opcional. Use TextureRect com `EXPAND_IGNORE_SIZE`, `STRETCH_KEEP_ASPECT_CENTERED` e filtro `NEAREST`. Não force as proporções: as fontes têm dimensões diferentes.

As cartas completas já incluem moldura e texto: não sobreponha outra moldura ou outro texto a esses PNGs. Para nova composição dinâmica, use as molduras isoladas e imagens separadas; as ilustrações da maior parte das cartas não existem como camadas independentes.

## Limitações reais dos assets
As primeiras cartas foram aprovadas como imagens achatadas em pranchas. O pacote exporta a coluna escolhida sem regenerar a arte. Os rótulos de variação e parte do fundo de apresentação permanecem quando existem na fonte; textos e molduras dessas cartas não são camadas separadas. Não foi feita remoção artificial de fundo que pudesse danificar as bordas.

As molduras Celestiais do Guerreiro e do Mago foram recebidas como imagens na conversa, mas seus PNGs isolados não estão disponíveis no sistema de arquivos. As duas cartas finais estão incluídas normalmente; não foi inventada ou reconstruída uma moldura de substituição. Reanexar os dois PNGs vazios permite completar essas duas entradas.

A moldura vazia da Arqueira é o original aprovado antes da alteração perolada. A faixa verde cromática perolada está na carta final PNG e na montagem SVG incluída; o desenho do PNG original da moldura foi preservado. As fontes finais do Guerreiro e Mago conservam também suas alternativas na prancha de origem.

A cena demonstra assets e importação, não implementa combate. Os valores no JSON seguem as propostas e escolhas da sessão. As decisões ainda não fechadas sobre contadores e ordem de aplicação estão explicitamente listadas no JSON; não foram inventadas regras adicionais.

## Validação
Com o projeto importado:
```
godot --headless --path . --editor --import
godot --headless --path . --script godot/validar_assets.gd
```
`docs/validacao.txt` registra os testes executados no ambiente. `SHA256SUMS.txt` verifica os arquivos do pacote. A pasta `fontes/` tem `.gdignore` para não importar estudos e referências como texturas do jogo.
