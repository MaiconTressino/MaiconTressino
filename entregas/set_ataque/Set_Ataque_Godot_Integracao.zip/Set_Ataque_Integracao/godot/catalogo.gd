extends Control
## Exemplo visual de Godot 4. Não implementa combate nem aplica os efeitos do JSON.

func _ready() -> void:
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://data/set_ataque.json"))
	if not data is Dictionary:
		push_error("Catálogo de cartas inválido.")
		return
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 18)
	grid.add_theme_constant_override("v_separation", 18)
	scroll.add_child(grid)
	for card in data["cartas"]:
		var box := VBoxContainer.new()
		box.custom_minimum_size = Vector2(280, 440)
		grid.add_child(box)
		var title := Label.new()
		title.text = str(card["nome"])
		title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(title)
		var image := TextureRect.new()
		image.custom_minimum_size = Vector2(280, 390)
		image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		image.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		image.texture = load(str(card["textura"]))
		image.tooltip_text = str(card["efeito"])
		box.add_child(image)
