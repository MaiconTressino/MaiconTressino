extends SceneTree
## Valida importação real, distribuição e arquivos sem iniciar o jogo do usuário.

func _initialize() -> void:
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://data/set_ataque.json"))
	if not data is Dictionary or not data.has("cartas"):
		_fail("JSON inválido")
		return
	var cards: Array = data["cartas"]
	if cards.size() != 22:
		_fail("Quantidade de cartas diferente de 22")
		return
	var ids := {}
	var counts := {}
	for card in cards:
		if ids.has(card["id"]):
			_fail("ID duplicado")
			return
		ids[card["id"]] = true
		var rarity: String = card["raridade"]
		counts[rarity] = int(counts.get(rarity, 0)) + 1
		var texture = load(str(card["textura"]))
		if not texture is Texture2D or texture.get_width() <= 0 or texture.get_height() <= 0:
			_fail("Textura não importada: " + str(card["textura"]))
			return
	var expected := {"comum":4,"incomum":4,"rara":3,"epica":3,"lendaria":3,"mitica":2,"celestial":3}
	for rarity in expected:
		if counts.get(rarity, 0) != expected[rarity]:
			_fail("Distribuição incorreta: " + rarity)
			return
	var frames = JSON.parse_string(FileAccess.get_file_as_string("res://data/molduras.json"))
	for frame in frames["disponiveis"]:
		if not load(str(frame["arquivo"])) is Texture2D:
			_fail("Moldura não importada")
			return
	print("VALIDACAO_OK: 22 cartas, 7 molduras, IDs únicos e distribuição 4/4/3/3/3/2/3.")
	quit(0)

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
